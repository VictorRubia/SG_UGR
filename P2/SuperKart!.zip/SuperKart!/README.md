# What a Night_SG_P2_UGR
 Juego de navegador realizado con ThreeJS para la práctica 2 de la asignatura Sistemas Gráficos de la UGR.
 Juega [aquí](https://marinahbau.github.io/What-a-Night_SG_P2_UGR/js/index.html)
