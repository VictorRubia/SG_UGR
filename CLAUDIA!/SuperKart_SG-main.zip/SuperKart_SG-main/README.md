<img src="https://secretariageneral.ugr.es/pages/ivc/descarga/_img/vertical/ugrmarca01color_2/!/download" align="right" width="20%" />

# Sistemas Gráficos
> Asignatura 3º de Grado en Ingeniería Informática de la especialidad en Software.

## Práctica 2

Juego de carreras

Pulse [aquí](https://victorrubia.github.io/SuperKart_SG/js) para jugar


## Licencia

[![CC0](https://licensebuttons.net/l/by-nc-nd/4.0/88x31.png)](https://creativecommons.org/publicdomain/zero/1.0/)
